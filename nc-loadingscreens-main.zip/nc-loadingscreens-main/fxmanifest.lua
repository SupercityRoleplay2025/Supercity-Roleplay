fx_version 'adamant'
game 'gta5'

author 'NaorNC#8998' -- # Discord - Discord.gg/cKt4Mpd2PQ
description 'nc-loadingscreen'

files {
    '*.html',
    'assets/**/*.*',
    'assets/**/**/*.*'
}

client_script 'client.lua'

--loadscreen_manual_shutdown "yes"
loadscreen 'index.html'