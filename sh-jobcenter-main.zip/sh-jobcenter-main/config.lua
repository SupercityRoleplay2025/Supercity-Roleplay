return {
    texts = {
        open = '[~g~E~w~] - Job Center'
    },

    job_centers = {
        locations = {
            vector3(-267.43, -959.08, 31.22),
        },
        draw_distance = 7.0,
        radius = 2.5, -- interaction radius
    }
}