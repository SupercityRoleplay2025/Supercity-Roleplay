CFG = {}
CFG.SETTINGS = {
    -- UI settings are located at html/config.js folder
    -- list of control keys https://docs.fivem.net/docs/game-references/input-mapper-parameter-ids/keyboard/

    command = 'guidebook', -- name of command
    keybind = 'F1', -- control key or false to disable it
}