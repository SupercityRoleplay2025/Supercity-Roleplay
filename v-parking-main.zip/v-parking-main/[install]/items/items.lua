['ticket'] = {
    label = 'Parking Ticket',
    weight = 1000,
    consume = 0,
    server = {
        export = 'v-parking.useTicket'
    }
},
['clamp'] = {
    label = 'Tire Clamp',
    description = "Clamp that mf",
    weight = 2500,
},