fx_version 'cerulean'
game 'gta5'

author "Fruit Scripts"

lua54 'yes'

files {
    'config.js',
    'config.css',
    'html/**/'
}

loadscreen 'html/index.html'
loadscreen_cursor 'yes'