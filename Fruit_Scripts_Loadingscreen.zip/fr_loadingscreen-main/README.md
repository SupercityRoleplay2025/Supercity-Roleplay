# fr_loadingscreen
Loadingscreen resource for Fivem servers

## PREVIEW
<a href="https://ibb.co/YZhrmkx"><img src="https://i.ibb.co/X8tw1sq/2023-05-13-21-49-14-by-Fruit-Scriptsa.png" alt="2023-05-13-21-49-14-by-Fruit-Scriptsa" border="0"></a>
## [VIDEO PREVIEW](https://www.youtube.com/watch?v=X2i5Wj1sNc4&ab_channel=FruitTea)
