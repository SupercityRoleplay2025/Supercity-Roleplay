Config = {};

Config.UpperName = "Fruit"
Config.LowerName = "Scripts"
Config.Title = "OUR TEAM"

Config.Logo = "assets/logo.png"

Config.Team = [
    {name: "FruitTea#9543", description: "Admin", image: "assets/person.png"},
    {name: "FruitTea#9543", description: "Admin", image: "assets/person.png"},
    {name: "FruitTea#9543", description: "Admin", image: "assets/person.png"},
    {name: "FruitTea#9543", description: "Admin", image: "assets/person.png"},
];

Config.Socials = [
    {copytext: "https://discord.gg/8aZV9DDrj8", image: "assets/website.png", help: "Copy to clipboard", success: "Copied Link"},
    {copytext: "https://discord.gg/8aZV9DDrj8", image: "assets/discord.png", help: "Copy to clipboard", success: "Copied Link"},
    {copytext: "https://discord.gg/8aZV9DDrj8", image: "assets/youtube.png", help: "Copy to clipboard", success: "Copied Link"},
];

Config.Songs = [
    "music/music1.mp3",
    "music/music2.mp3",
    "music/music3.mp3",
    "music/music4.mp3",
    "music/music5.mp3",
    "music/music6.mp3",
];
